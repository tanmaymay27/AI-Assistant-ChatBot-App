"""az_proj URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from links.views import main_func,home_view, update_prices,export_data_to_excel ,LinkDeleteView 

urlpatterns = [
    path('admin/', admin.site.urls),
    path('tracker/',home_view,name = 'tracker'),
    path('',main_func,name = 'home'),
    path('export/',export_data_to_excel,name = 'export-data'),
    path('update/',update_prices,name = 'update-prices'),
    path('delete/<pk>/', LinkDeleteView.as_view(),name='delete'),
]
